# Joseph Aria Reflexology — Chinese Reflexology Wellness

A responsive, single-page static website for GitHub Pages.

## Files
- `index.html` — complete website, styles, session-plan interaction and client tools.

## Publish using GitHub Pages (Android-friendly)
1. Create a public GitHub repository, for example `joseph-aria-reflexology`.
2. Open the repository and choose **Add file → Create new file**.
3. Name the file `index.html`.
4. Copy all content from the supplied `index.html` into GitHub's editor and commit it to `main`.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
7. Wait for GitHub Pages to publish and use the displayed **Visit site** link.

GitHub Pages hosts static HTML/CSS/JavaScript and does not require an API key for this website. Changes may take several minutes to appear.

## Important notes
- Client records are not uploaded or saved by the website. Use the printable record carefully and keep completed records private.
- This is educational wellness content, not medical advice or a validated clinical protocol.
- Holly Tse's copyrighted charts are linked as original references and are not copied into the website. The requested five hand points are not attributed to her until the exact set can be verified from a primary source.
- Review safety and consent wording for local professional and legal requirements before offering services.
